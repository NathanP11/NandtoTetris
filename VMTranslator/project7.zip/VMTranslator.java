package VMTranslator;

public class VMTranslator {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		parser myParser = new parser(args[0]);
		//System.out.println("Reading File: " + args[0]);
		CodeWriter myWriter = new CodeWriter(args[0]);
		
		while(myParser.hasMoreCommands()) {
			//iterate thru all commands
			myParser.advance();
			myWriter.writeLine("//" + myParser.line);
			
			System.out.println("//" + myParser.line);
			System.out.println("commandType: " +myParser.commandType());
			System.out.println("arg1: " +myParser.arg1());
			System.out.println("arg2: " + myParser.arg2());
			
			String C_TYPE = myParser.commandType();
			if(C_TYPE.equals("C_ARITHMETIC")) {
				myWriter.writeArithmetic(myParser.arg1());
			}
			if(C_TYPE.equals("C_PUSH") || C_TYPE.equals("C_POP") ) {
				myWriter.writePushPop(C_TYPE,myParser.arg1(),myParser.arg2());
				
			}
		}
		myWriter.closeFile();
	}

}
