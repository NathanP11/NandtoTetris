package VMTranslator;
import java.io.File;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Scanner;
import org.apache.commons.io.*;
import java.io.FileWriter;   // Import the FileWriter class
import java.io.IOException;  // Import the IOException class to handle errors

public class CodeWriter {
	int k = 0; // program counter 
	File f;
	FileWriter myWriter;
	
	CodeWriter(String fileName){ //constructor
		try {
		String newFileName = fileName.substring(0,fileName.lastIndexOf(".")) + ".asm";
        f = new File(newFileName);
        myWriter = new FileWriter(f);
		} catch (IOException e) {
			System.out.println("Error Opening File.");
			e.printStackTrace();	}
        ////////////////////////////////////////////////////////////////////////////////// 
	}
	
	public void writePushPop(String cmd, String type, int index) {
		//to do
		Boolean trigger = false;
		try {
			if(type.equals("pointer")) {
				index = index + 3;
				type = "constant"; 			
				trigger = true;}
			if(type.equals("temp")) {
				index = index + 5;
				type = "constant"; 			
				trigger = true;}
			
		if(cmd.equals("C_PUSH")) {
			if(type.equals("static")) {
				myWriter.write("@"+ f.getName().substring(0,f.getName().lastIndexOf(".")) + "." + index  + "\r\n");
				System.out.println("static output push: @"+ f.getName().substring(0,f.getName().lastIndexOf(".")) + "." + index  + "\r\n");
				trigger = true;
				type = "constant";
			}
			else {myWriter.write("@"+ index + "\r\n");}  //@index  
			
			myWriter.write("D=A"+ "\r\n"); 
			if(!(type.equals("constant"))) {
				myWriter.write("@"+ type + "\r\n");  //@LCL,ARG,THIS,THAT
				myWriter.write("A=D+M"+ "\r\n"); //BASE ADDRESS + INDEX
				myWriter.write("D=M"+ "\r\n"); 	//SAVE OUTPUT TO D REGISTER
			}
			if(trigger) {   //pointer & temp
				myWriter.write("D=M"+ "\r\n"); //BASE ADDRESS + INDEX
				//myWriter.write("D=A"+ "\r\n"); 	//SAVE OUTPUT TO D REGISTER
			}
			myWriter.write("@SP"+ "\r\n"); 		//GET STACK PTR
			myWriter.write("A=M"+ "\r\n"); 		//ACCESSES STACK PTR
			myWriter.write("M=D"+ "\r\n"); 		//WRITE TO STACK
			myWriter.write("@SP"+ "\r\n"); 		//
			myWriter.write("M=M+1"+ "\r\n"); 	//SP++
		}
		if(cmd.equals("C_POP")) {
			if(type.equals("static")) {
				myWriter.write("@"+ f.getName().substring(0,f.getName().lastIndexOf(".")) + "." + index  + "\r\n");
				System.out.println("static output pop: @"+ f.getName().substring(0,f.getName().lastIndexOf(".")) + "." + index  + "\r\n");
				type = "constant";
			}
			else {myWriter.write("@"+ index + "\r\n"); 		}
			
			myWriter.write("D=A"+ "\r\n"); 
			
			if(!(type.equals("constant"))) {
				myWriter.write("@"+ type + "\r\n"); 		
				myWriter.write("D=D+M"+ "\r\n"); 
			}
			myWriter.write("@SP" + "\r\n"); 		
			myWriter.write("M=M-1"+ "\r\n"); 
			myWriter.write("A=M+1"+ "\r\n"); 
			myWriter.write("M=D"+ "\r\n"); 
			myWriter.write("A=A-1"+ "\r\n"); 
			myWriter.write("D=M"+ "\r\n"); 
			myWriter.write("A=A+1"+ "\r\n");
			myWriter.write("A=M"+ "\r\n");
			myWriter.write("M=D"+ "\r\n");
		}

		}catch (IOException e) {
		     System.out.println("Error Writing to File.");
		     e.printStackTrace();}
	}
	
	public void writeArithmetic(String cmd) {
		// pop 1 value into temporary memory, 1 value into D register
		
		try {//2 parameter computations
			if( !(cmd.equals("neg") || cmd.equals("not")) )  {
				//do this in main myWriter.write("//" + cmd + "\r\n");
				myWriter.write("@SP"+ "\r\n");     
				myWriter.write("AM=M-1"+ "\r\n");  //SP--
				myWriter.write("D=M"+ "\r\n");     //put stack pointer tgt in D
				myWriter.write("A=A-1"+ "\r\n");   //get 2nd stack data pointer
				myWriter.write("A=M"+ "\r\n");	   //get 2nd stack data
				
				if(cmd.equals("add")) { myWriter.write("D=D+A"+ "\r\n"); }
				if(cmd.equals("sub")) { myWriter.write("D=A-D"+ "\r\n"); }
				
				if(cmd.equals("eq")) { 
					myWriter.write("D=D-A"+ "\r\n"); 
					myWriter.write("@assign1"+ k + "\r\n");
					myWriter.write("D;JEQ"+ "\r\n");
					myWriter.write("@assign0"+ k + "\r\n");
					myWriter.write("0;JMP"+ "\r\n");
					
					myWriter.write("(assign1"+ k + ")" + "\r\n");
					myWriter.write("D=-1"+ "\r\n");
					myWriter.write("@stackWrite"+ k + "\r\n");
					myWriter.write("0;JMP"+ "\r\n");
					
					myWriter.write("(assign0"+ k + ")" + "\r\n");
					myWriter.write("D=0"+ "\r\n");
					myWriter.write("@stackWrite"+ k + "\r\n");
					myWriter.write("0;JMP"+ "\r\n"); 
					
				}
				
				//not done yet
				if(cmd.equals("gt")) { 
					myWriter.write("D=D-A"+ "\r\n");
					myWriter.write("@assign1"+ k + "\r\n");
					myWriter.write("D;JLT"+ "\r\n"); //important line
					myWriter.write("@assign0"+ k + "\r\n");
					myWriter.write("0;JMP"+ "\r\n");
	
					myWriter.write("(assign1"+ k + ")" + "\r\n");
					myWriter.write("D=-1"+ "\r\n");
					myWriter.write("@stackWrite"+ k + "\r\n");
					myWriter.write("0;JMP"+ "\r\n");
					
					myWriter.write("(assign0"+ k + ")" + "\r\n");
					myWriter.write("D=0"+ "\r\n");
					myWriter.write("@stackWrite"+ k + "\r\n");
					myWriter.write("0;JMP"+ "\r\n"); 
					
				}
					
				if(cmd.equals("lt")) { 
					myWriter.write("D=D-A"+ "\r\n");
					myWriter.write("@assign1"+ k + "\r\n");
					myWriter.write("D;JGT"+ "\r\n");//important line
					myWriter.write("@assign0"+ k + "\r\n");
					myWriter.write("0;JMP"+ "\r\n");
	
					myWriter.write("(assign1"+ k + ")" + "\r\n");
					myWriter.write("D=-1"+ "\r\n");
					myWriter.write("@stackWrite"+ k + "\r\n");
					myWriter.write("0;JMP"+ "\r\n");
					
					myWriter.write("(assign0"+ k + ")" + "\r\n");
					myWriter.write("D=0"+ "\r\n");
					myWriter.write("@stackWrite" + k + "\r\n");
					myWriter.write("0;JMP"+ "\r\n"); 
					
					}
				
				if(cmd.equals("and")) { myWriter.write("D=D&A"+ "\r\n"); }
				if(cmd.equals("or")) { myWriter.write("D=D|A"+ "\r\n"); }
				// write to stack
				
				myWriter.write("(stackWrite" + k + ")"+ "\r\n");
				myWriter.write("@SP"+ "\r\n");
				myWriter.write("A=M-1"+ "\r\n");
				myWriter.write("M=D"+ "\r\n");
				k++;
				return;
			}
			else {//1 parameter computations
				myWriter.write("@SP"+ "\r\n");
				myWriter.write("A=M-1"+ "\r\n");
				if(cmd.equals("neg")) { myWriter.write("M=-M"+ "\r\n"); }
				if(cmd.equals("not")) { myWriter.write("M=!M"+ "\r\n"); }
				return;
			}
		}catch (IOException e) {
		     System.out.println("Error Arithmetic to file Writing to File.");
		     e.printStackTrace();
		}
		return;
	}
	
	public void writeLine(String s) {
		try {
		myWriter.write(s + "\r\n");
		}catch (IOException e) {
		     System.out.println("Error Writing to File.");
		     e.printStackTrace();
		}
	}
	
	public void closeFile() {
		try {
		myWriter.close();
		}catch (IOException e) {
		     System.out.println("Error Closing File.");
		     e.printStackTrace();
		}
	}
	
	//new class here
	
}
